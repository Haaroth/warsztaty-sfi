(function() {
	var app = angular.module("CookBookApp", ["recipesModule", "ngRoute", 'ngAnimate']);

	app.config(function($routeProvider) {
		$routeProvider.when("/", {templateUrl : "/partials/home.html"})
					  .when("/recipe/:recipeId", {templateUrl : "/partials/recipe.html", controller : "recipeController"})
					  .otherwise({redirectTo : "/"});
	});

	app.controller("CookBookController", function($scope, recipesService, $routeParams, $location) {

		var init = function() {
			$scope.recipes = [];
			recipesService.getAllRecipes().then(
					function (res) {
						$scope.recipes = res;
					},
					function (err) {
						alert(err);
					}
				);
		}

		$scope.isActive = function(id) {
			return $routeParams.recipeId == id;
		}

		$scope.addRecipe = function() {
			recipesService.addRecipe({name: "", ingredients: [], desc: ""}).then(
					function(res) {
						$location.url("/recipe/"+res.id+"?editMode=true");
					},
					function(err) {

					}
				);
		}

		init();

	})
})();