(function() {
	
	var recipesModule = angular.module('recipesModule', []);

	var getAllRecipesInternal = function(defer, $http) {
		$http.get("/resources/recipes.json").then(
				function(res) {
					recipes = res.data;
					defer.resolve(recipes);
				},
				function(err) {
					defer.reject(err);
				}
			);
	}

	var getRecipeInternal = function(defer, id) {
		if (id < 0 || id >= recipes.length) {
			defer.reject("Nie znaleziono takiego przepisu.");
		} else {
			defer.resolve(recipes[id]);
		}
	}

	var deleteRecipeInternal = function(defer, id) {
		if (id < 0 || id >= recipes.length) {
			defer.reject("Nie znaleziono takiego przepisu.");
		} else {
			recipes.splice(id,1);
			defer.resolve({status: "ok"});
		}
	}

	var addRecipeInternal = function(defer, recipe) {
		recipes.push(recipe);
		defer.resolve({id: recipes.length -1});
	}

	recipesModule.service('recipesService', function($q, $http) {
		var service = this;

		service.getAllRecipes = function() {
			var defer = $q.defer();
			getAllRecipesInternal(defer, $http);
			return defer.promise;
		}

		service.getRecipe = function(id) {
			var defer = $q.defer();
			getRecipeInternal(defer, id);
			return defer.promise;
		}

		service.deleteRecipe = function(id) {
			var defer = $q.defer();
			deleteRecipeInternal(defer, id);
			return defer.promise;
		}

		service.addRecipe = function(recipe) {
			var defer = $q.defer();
			addRecipeInternal(defer, recipe);
			return defer.promise;
		}

		return service;
	});

	recipesModule.controller("recipeController", function($scope, recipesService, $routeParams, $location){
		var init = function() {
			$scope.editMode = $location.search().editMode;
			$scope.newIngredient = null;
			$scope.recipe = {name: "", ingredients: [], desc : ""};
			recipesService.getRecipe($routeParams.recipeId).then(
					function(res) {
						$scope.recipe = res;
					},
					function(err) {
						$location.path("/");
					}
				);
		}

		$scope.switchEditMode = function() {
			$scope.editMode = !$scope.editMode;
		}
 
		$scope.removeIgredient = function(id) {
			$scope.recipe.ingredients.splice(id, 1);
		}

		$scope.addIngredient = function() {
			$scope.recipe.ingredients.push($scope.newIngredient);
			$scope.newIngredient = null;
		}

		init();
	});

	var recipes = [
	{
		"name": "Kapuśniak po litewsku",
		"ingredients": [
			"50 dag wędzonki",
			"30 dag kapusty kiszonej",
			"20 dag kapusty białej",
			"1 marchewka",
			"1 pietruszka",
			"5 suszonych prawdziwków",
			"1 cebula",
			"1 łyżka mąki",
			"2 łyżki smalcu",
			"1 łyżka przecieru pomidorowego",
			"kilka ziaren pieprzu",
			"1 listek laurowy",
			"sól"
			],
		"desc": "Litwini nie wyobrażają sobie kuchni bez kiszonej kapusty - podobnie zresztą jak większość Polaków, Niemców czy Węgrów. Litewski kapuśniak to danie chłopskie - ugotowany na wędzonce jest solidny i pożywny. Grzyby namocz na noc. Obierz marchewkę i pietruszkę. Wędzonkę zalej 3 l zimnej wody, dodaj marchewkę, pietruszkę i grzyby. Wrzuć listek laurowy i pieprz, gotuj 45 minut. Posiekaj kapustę kwaszoną, poszatkuj kapustę białą. Obie kapusty przełóż do rondla, zalej szklanką wody, dodaj 1 łyżkę smalcu. Gdy kapusta będzie miękka, posiekaj cebulę, podsmaż ją na pozostałym smalcu. Oprósz mąką, wymieszaj z przecierem pomidorowym, a potem dodaj do kapusty. Mieszając, duś przez chwilę. Wlej przecedzony wywar z wędzonki. Grzybki pokrój w cienkie paseczki i również dodaj do kapuśniaku. Przypraw do smaku."
	},
	{
		"name": "Placki ziemniaczane",
		"ingredients": [
			"1 kg ziemniaków",
			"1 mała cebula",
			"3 czubate łyżki mąki (lub więcej jeśli ziemniaki są wodniste)",
			"1 jajko",
			"sól",
			"pieprz",
			"olej do smażenia"
			],
		"desc": "Ziemniaki obierz i zetrzyj na tarce o takich oczkach, jaką fakturę placka najbardziej lubisz. Lekko odciśnij nadmiar płynu, dodaj drobniutko posiekaną cebulę (możesz też zetrzeć ją na tarce), mąkę, jajko, dopraw solą oraz pieprzem i dokładnie wymieszaj. Dowolnej wielkości placki smaż z obu stron na patelni na rozgrzanym oleju, aż będą złocisto-brązowe. Podawaj z ulubionymi dodatkami."
	},
	{
		"name": "Barszcz po ukraińsku na wędzonym kurczaku",
		"ingredients": [
			"1 kg buraków",
			"2 sztuki wędzonych udek z kurczaka",
			"2 jajka ugotowane na twardo",
			"5 średnich ziemniaków",
			"1/2 puszki groszku konserwowego",
			"1/2 słoika zielonej fasolki szparagowej",
			"2 marchewki",
			"2 korzenie pietruszki",
			"100 g szynki",
			"200 g tłustej kiełbasy",
			"5 ziaren ziela angielskiego",
			"4 liście laurowe",
			"Szczypta suszonego majeranku",
			"Łyżka natki pietruszki",
			"Sól i pieprz do smaku",
			"200 g śmietany 12%"
		],
		"desc": "Umyte, obrane i przekrojone na pół buraki gotujemy razem z przyprawami (solą, pieprzem, zielem angielskim, liśćmi laurowymi i majerankiem) na barszcz. Po ok. 40 min do gotującego się barszczu dodajemy starte na tarce - na dużych oczkach marchewki i pietruszki oraz pokrojone w kostkę ziemniaki. Razem z tymi jarzynami dodajemy do barszczu obrane i pokrojone w kostkę udka z kurczaka oraz pokrojone w kostkę szynkę i kiełbasę. Następnie, po ok. 20 min dodajemy groszek i fasolkę. Całość gotujemy jeszcze 20 min. Po nałożeniu na talerze dodajemy pokrojone w ćwiartki jajka na twardo i posypujemy natką pietruszki. Można również dodać śmietanę do smaku."
	},
	{
		"name": "Karkówka wolno pieczona",
		"ingredients": [
			"1kg karkówki",
			"3 cebule",
			"0.25 szklanki sosu sojowego",
			"1 szklanka bulionu wołowego",
			"3 liście laurowe",
			"1 ząbek czosnku",
			"1 łyżeczka oregano",
			"1 łyżka oleju",
			"sól"
		],
		"desc": "Mięso natrzeć solą, pieprzem i obsmażyć na oleju ze wszystkich stron. Cebule posiekać. Sos sojowy połączyć z bulionem, liśćmi laurowymi, czosnkiem i oregano.Wszystkie składniki połączyć razem w naczyniu żaroodpornym. Piec 5 godzin w temperaturze 160 stopni.Podawać z ryżem lub ziemniakami według uznania."
	},
	{
		"name": "Burger",
		"ingredients": [
			"1 kg mięsa (70-80% mięsa z łopatki i 20% tłustego mięsa lub słoniny wołowej)",
			"olej rzepakowy do smażenia",
			"sos Worcestershire",
			"4 plastry cheddara lub mimolette",
			"4 bułki najlepiej ciemne",
			"masło",
			"plastry pomidora",
			"krążki cebuli",
			"ogórki kiszone",
			"liście sałaty"
		],
		"desc": "Przepuszczamy mięso przez maszynkę. Nie przyprawiamy, a przede wszystkim nie solimy, bo będzie wysuszone. Powinno być zimne, żeby się nie lepiło. Mielemy tylko raz. Jeżeli nie mamy maszynki, możemy poprosić o zmielenie w sklepie.Burgery najwygodniej uformować specjalną obręczą, ale można to zrobić ręką. Mięsa nie ugniatamy, bo będzie zbyt ścisłe. Gotowe krążki mięsa odkładamy na papier śniadaniowy.Smażymy burgery na średnio gorącym oleju (jak będzie za zimny, to mięso zrobi się szare). W kuchni elektrycznej oznacza to zwykle poziom 7 na pokrętle. Olej nie powinien się dymić. Czy jest wystarczająco gorący, można sprawdzić, wpuszczając doń kropelkę wody. Jeśli skwierczy i momentalnie wyparowuje, ma odpowiednią temperaturę. Posypujemy grubo zmielonym czarnym pieprzem i solą. Odwracamy i znów przyprawiamy. Jeśli macie termometr do mięsa, łatwo sprawdzić stopień wysmażenia burgera.Średnio wysmażony powinien mieć w środku ok. 60°C. Jedną stronę hamburgera polewamy sosem Worcestershire.Na usmażonego burgera kładziemy plasterek sera i czekamy, by się trochę roztopił. Podsmażamy na maśle bułki. Do hamburgera dodajemy plaster pomidora, krążek cebuli, dwa plasterki kiszonych ogórków i liść sałaty."
	},
	{
		"name": "Spring rolls",
		"ingredients": [
			"opakowanie papieru ryżowego",
			"ulubione chrupiące warzywa - pocięte w słupki lub poszatkowane np.:",
			"marchewka",
			"papryka",
			"kapusta pekińska",
			"kalarepa",
			"groszek cukrowy",
			"rzodkiewki",
			"opcjonalnie także:",
			"kiełki",
			" grzyby (np. shitake)",
			"posiekana kolendra",
			"do podania: sos sojowy albo sweet chilli"
		],
		"desc": "Przygotuj miskę z letnią wodą oraz deskę do zwijania spring rolls. Arkusze papieru mocz w wodzie aż zmiękną i układaj na desce. Na każdym arkuszu, blisko jednego z brzegów, kładź mieszankę ulubionych warzyw. Bliższy brzeg zawiń na warzywa, następnie złóż do środka boczne brzegi, aby zabezpieczyć nadzienie przed wypadaniem, a później zawiń rulonik do końca. Podawaj od razu z dodatkiem sosu."
	},
	{
		"name": "Łopatka wołowa w piwie",
		"ingredients": [
			"2 łyżki oliwy",
			"1.5 kg łopatki wołowej",
			"posiekana cebula",
			"5 rozgniecionych ząbków czosnku",
			"500 g marchewek pokrojonych na kawałki",
			"250 g grzybów (mogą być pieczarki lub leśne) pokrojonych w plasterki",
			"700 g ziemniaków (obranych i pokrojonych na kawałki)",
			"2 łyżki mąki",
			"2 szklanki dobrego bulionu wołowego",
			"butelka (350 ml) ciemnego piwa",
			"listek laurowy",
			"3 łyżki posiekanego świeżego tymianku",
			"łyżeczka brązowego cukru",
			"2 łyżki musztardy z całymi ziarenkami gorczycy",
			"łyżka koncentratu pomidorowego",
			"sól",
			"grubo mielony pieprz"
		],
		"desc": "Rozgrzewamy piekarnik do 180°C. W brytfannie podsmażamy mięso ze wszystkich stron na oliwie. Wyjmujemy z brytfanny. Na tym samym tłuszczu smażymy cebulę i czosnek, po 5 minutach wkładamy marchewki, grzyby i ziemniaki. Smażymy 2-3 minuty, mieszając. Oprószamy mąką, smażymy jeszcze minutę, nie przerywając mieszania. Wlewamy bulion i piwo, zagotowujemy, mieszając. Dodajemy listek laurowy, tymianek, cukier, musztardę i koncentrat, przyprawiamy solą i pieprzem. Na warzywach układamy mięso, przykrywamy i pieczemy, aż mięso będzie zupełnie miękkie - co najmniej 2,5 godziny."
	}
];
})();